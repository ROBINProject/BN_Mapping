package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class webQ_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n");
      out.write("  Copyright © 2009  Norsys Software Corp.\r\n");
      out.write("-->\r\n");
      norsys.netica.jspprojects.webq.WebQBean webQ = null;
      synchronized (session) {
        webQ = (norsys.netica.jspprojects.webq.WebQBean) _jspx_page_context.getAttribute("webQ", PageContext.SESSION_SCOPE);
        if (webQ == null){
          webQ = new norsys.netica.jspprojects.webq.WebQBean();
          _jspx_page_context.setAttribute("webQ", webQ, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
 
   webQ.processRequest(request); //upon each invocation, process the request
   //webQ.ensureInitialized();  //why is this not sufficient?
 
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("  <head>\r\n");
      out.write("    <title>webQ.jsp: sample JSP project calling Netica on server</title>\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"default.css\">\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"/css/");
      out.print( webQ.getCurrentPageStyles() );
      out.write("\">\r\n");
      out.write("    <style type=\"text/css\">\r\n");
      out.write("    </style>\r\n");
      out.write("\r\n");
      out.write("    <script language=\"JavaScript\" type=\"text/javascript\" src=\"default.js\"></script> \r\n");
      out.write("  </head>\r\n");
      out.write("\r\n");
      out.write("<body bgcolor=\"white\">\r\n");
      out.write("\r\n");
      out.write("<form type=post action=\"webQ.jsp\">\r\n");
      out.write("\r\n");
      out.write("<table width=\"100%\" border=0 cellspacing=0 cellpadding=5 bgcolor=\"#EEEEEF\">\r\n");
      out.write("<tr><td align=center><u>Norsys Netica Web Q Example</u><br>");
      out.print( webQ.getDate() );
      out.write("</center></td></tr>\r\n");
      out.write("<tr><td align=center>Net : <SELECT name=\"netSelected\" onchange=\"document.forms[0].submit();\">\r\n");
      out.write("                ");
      out.print( webQ.getHTMLSelectOptions("Net Names") );
      out.write("\r\n");
      out.write("              </SELECT>\r\n");
      out.write("\r\n");
      out.write("&nbsp \r\n");
      out.write("  <INPUT type=\"hidden\" name=\"reloadNet\" id=\"reloadNetId\" value=\"false\">\r\n");
      out.write("  <INPUT type=\"button\" name=\"reloadNetButton\" value=\"Reload Net\" \r\n");
      out.write("         style='background-color:#AAFFAA;display:");
      out.print( webQ.getBooleanProperty("showReloadNetButton",  false ) ? "inline": "none" );
      out.write("' \r\n");
      out.write("         onclick=\"doReloadNet();\">\r\n");
      out.write("</td></tr>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("</div>\r\n");
      out.write("<hr>\r\n");
      out.write("<span class=\"titleText\">");
      out.print( webQ.getNetUserField("WebQ_Title") );
      out.write("</span>\r\n");
      out.write("\r\n");
      out.write("<div class=\"tableBlurb\" >\r\n");
      out.write("<table width=\"100%\" border=0 cellspacing=0 cellpadding=0>\r\n");
      out.write("  <tr height=\"50px\" >\r\n");
      out.write("    <td>\r\n");
      out.write("      ");
      out.print( webQ.getNetUserField("WebQ_Blurb") );
      out.write("\r\n");
      out.write("    </td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("</div>\r\n");
      out.write("\r\n");
      out.write("<table width=\"100%\" border=0 cellspacing=0 cellpadding=4 style=\"border: 1 thin black\">\r\n");
      out.write("  <tr class=\"questionText\"><td>Unanswered Questions</td></tr> \r\n");
      out.write("  <tbody class=\"tableQ1_Unanswered\">\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Unanswered") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table width=\"100%\" border=0 cellspacing=0 cellpadding=4 style=\"border: 1 thin black\">\r\n");
      out.write("  <tr class=\"questionText\"><td>Resulting Probabilities</td></tr>\r\n");
      out.write("  <tbody class=\"tableQ2_Target\">\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Target") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("<div style=';display:");
      out.print( webQ.getBooleanProperty("showSubmitButtonAndRadioButtons",  false ) ? "inline": "none" );
      out.write("'>\r\n");
      out.write("  <center><INPUT id=submitButtonId    type=submit name=submitButton  ");
      out.print( webQ.getAutoSubmit()? "DISABLED":"" );
      out.write("\r\n");
      out.write("                 Value=\"Submit\" style=\"background-color:#AAFFAA\" >&nbsp;&nbsp;&nbsp;&nbsp; Submit: \r\n");
      out.write("          <INPUT  type=radio  name=autosubmit  value=\"false\"  onclick=\"disableSubmitButton(false);\"\r\n");
      out.write("\t         ");
      out.print( ! webQ.getAutoSubmit() ? "CHECKED":"" );
      out.write("> Manually\r\n");
      out.write("          <INPUT id=autosubmitRadioTrueId \r\n");
      out.write("\t          type=radio  name=autosubmit  value=\"true\"  onclick=\"disableSubmitButton(true);\"\r\n");
      out.write("\t         ");
      out.print(   webQ.getAutoSubmit() ? "CHECKED":"" );
      out.write("> Automatically</center>\r\n");
      out.write("</center>\r\n");
      out.write("</div>\r\n");
      out.write("\r\n");
      out.write("<INPUT type=submit name=resetFindings Value=\"Reset Findings\" style=\"background-color:#AACCFF\"><hr>\r\n");
      out.write("<br>\r\n");
      out.write("<br>\r\n");
      out.write("\r\n");
      out.write("<table class=\"tableQuestionsAnswered\" width=\"100%\" border=0 cellspacing=0 cellpadding=4\r\n");
      out.write("   style=';display:");
      out.print( webQ.getBooleanProperty("showAnsweredQuestions",  true ) ? "inline": "none" );
      out.write("'>\r\n");
      out.write("  <tr class=\"questionText\"><td colspan=\"50\">Answered Questions</td></tr>\r\n");
      out.write("  <tbody class=\"tableQ3_Answered\">\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Answered") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("<table class=\"tableQuestionsSkipped\" width=\"100%\" bordter=0 cellspacing=0 cellpadding=4\r\n");
      out.write("   style=';display:");
      out.print( webQ.getBooleanProperty("showSkippedQuestions",  true ) ? "inline": "none" );
      out.write("'>\r\n");
      out.write("  <tr class=\"questionText\"><td colspan=\"50\">Skipped Questions</td></tr>\r\n");
      out.write("  <tbody class=\"tableQ4_Skipped\">\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Skipped") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("<table class=\"tableQuestionsIrrelevant\" width=\"100%\" border=0 cellspacing=0 cellpadding=4\r\n");
      out.write("   style=';display:");
      out.print( webQ.getBooleanProperty("showIrrelevantQuestions",  true ) ? "inline": "none" );
      out.write("'>\r\n");
      out.write("  <tr class=\"questionText\"><td colspan=\"50\">Irrelevant Questions&nbsp;&nbsp;\r\n");
      out.write("     <input type=\"button\" name=\"irrelevantButton\" value=\"+\" onclick=\"javascript:handleIrrelevant(this);\" class=\"irrelevantButton\"></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  <tbody class=\"tableQ5_Irrelevant\" id=\"irrelevantBodyId\">\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Irrelevant") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("<hr>  \r\n");
      out.write("   ");
      out.print( webQ.getLog() );
      out.write("\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("\r\n");
      out.write("</html>\r\n");
      out.write("\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
