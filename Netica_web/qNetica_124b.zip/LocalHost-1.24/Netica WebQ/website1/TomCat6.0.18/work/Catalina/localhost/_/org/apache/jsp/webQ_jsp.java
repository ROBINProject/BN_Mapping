package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import norsys.netica.jspprojects.webq.WebQException;

public final class webQ_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!-- DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/strict.dtd\" -->\r\n");
      out.write("<!-- DOCTYPE HTML PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\" -->\r\n");
      out.write("<DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n");
      out.write("<!-- DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\" -->\r\n");
      out.write("<!-- DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\" \"http://www.w3.org/TR/html4/strict.dtd\" -->\r\n");
      out.write("<!-- !DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" -->\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<!--\r\n");
      out.write("  Copyright © 2009  Norsys Software Corp.\r\n");
      out.write("-->\r\n");
      out.write("\r\n");
      norsys.netica.jspprojects.webq.WebQBean webQ = null;
      synchronized (session) {
        webQ = (norsys.netica.jspprojects.webq.WebQBean) _jspx_page_context.getAttribute("webQ", PageContext.SESSION_SCOPE);
        if (webQ == null){
          webQ = new norsys.netica.jspprojects.webq.WebQBean();
          _jspx_page_context.setAttribute("webQ", webQ, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");

  response.setDateHeader ("Expires", 0); //prevent caching at the proxy server
//<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" 
//response.setDocType("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" >");
//response.setDocType("<!doctype HTML PUBLIC\"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">" );
//<jsp:output doctype-root-element="books" doctype-system="books.dtd" /> 

  String cssCacheModifier = "";
  String userId = ""; 
  boolean userExists = false;

  try{
   if ( "Refresh".equals( request.getParameter( "postBackAction" ) ) ) {
     webQ.processRefreshRequest(request);
     userId = webQ.getUserAccountName(request);
     userExists = userId  != null && userId.length() > 0;
   }
   else {
     webQ.processRequest(request); //upon each invocation, process the request
     userId = webQ.getUserAccountName(request);
     userExists = userId  != null && userId.length() > 0;

     if ( webQ.doNotCacheAnything() ) {
       //response.setHeader("Cache-Control","no-cache"); //HTTP 1.1
       //response.setHeader("Pragma","no-cache"); //HTTP 1.0


//response.setHeader("Cache-Control","no-store, no-cache, must-revalidate, max-age=0"); //HTTP 1.1
//response.addHeader("Cache-Control","post-check=0, pre-check=0");
//response.setHeader("Pragma","no-cache"); //HTTP 1.0
//response.setDateHeader ("Expires", -1);


        cssCacheModifier = "?V="+Math.random();
        webQ.log("NO CACHE");
      }
    }
  }
  catch (WebQException we) {
    if ( we.getId() == WebQException.WEBQ_EXCEPTION_INVALID_DEVELOPER_ACCOUNT ) {
    	response.sendRedirect("invalidAccount.html");
    }
    if ( we.getId() == WebQException.WEBQ_EXCEPTION_BLOCKED_DEVELOPER_ACCOUNT ) {
    	response.sendRedirect("blockedAccount.html");
    }
    else if ( we.getId() == WebQException.WEBQ_INTERNAL_CRASH_FORCES_SESSION_EXPIRY ) {
	request.getSession().invalidate();
    	response.sendRedirect("sessionExpiryWasForced.html");
    }
    else {
      webQ.log("Unhandled Exception:\n");
      webQ.log(we.getMessage());
    }
  }

 
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\" xml:lang=\"en\">\r\n");
      out.write("<head>\r\n");
      out.write("  <title>");
      out.print( webQ.getStringProperty( "WindowTitle", "windowTitle", "" ) );
      out.write("</title>\r\n");
      out.write("  <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" /> \r\n");
      out.write(" \r\n");
      out.write("  <script language=\"JavaScript\" type=\"text/javascript\" src=\"default.js\"></script> \r\n");
      out.write("  <script language=\"JavaScript\" type=\"text/javascript\" src=\"wqs.js\"></script> \r\n");
      out.write("  <link rel=\"stylesheet\" href=\"default.css");
      out.print( cssCacheModifier );
      out.write("\">\r\n");
      out.write("  ");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<style>\r\n");
      out.write("<!--\r\n");
      out.print( webQ.getCurrentPageEmbeddedStyles() );
      out.write("\r\n");
      out.write("-->\r\n");
      out.write("</style>\r\n");
      out.write("</head>\r\n");
      out.write("\r\n");
      out.write("<body bgcolor=\"white\" style='margin:0' onload=\"wqs_init();wq_init();\">\r\n");
      out.write("<div class=\"ttip\" id='tt'></div>\r\n");
      out.write("\r\n");
      out.write("<form action=\"webQ.jsp\" method=\"post\">\r\n");
      out.write("\r\n");
      out.write("  ");
      out.print( webQ.getReposts() );
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("   ");
      out.write("\r\n");
      out.write("   ");
      out.write("\r\n");
      out.write("   ");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table  class=\"neticaHeaderTable\" width=\"100%\" border=0 cellspacing=0 cellpadding=5 bgcolor=\"#EEEEEF\" >\r\n");
      out.write("<tr>\r\n");
      out.write("   ");
      out.write("\r\n");
      out.write("   <td style=\"padding:0;padding-left:10px;width:20%;text-decoration:none\">\r\n");
      out.write("     ");
      out.print( webQ.getStringProperty( "TopLeftCellHtml", "topLeftCellHtml", "" ) );
      out.write("\r\n");
      out.write("   </td>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("   ");
      out.write("\r\n");
      out.write("    <td class=\"neticaTitle\" align=\"center\" valign=\"top\">\r\n");
      out.write("\t");
      out.print( webQ.getStringProperty( "PageTitle", "pageTitle", "Norsys Netica Web-Q" ) );
      out.write("&nbsp;\r\n");
      out.write("       <a href=\"javascript:void(0);\" onclick=\"showWebQHelp();\"><img src='");
      out.print( webQ.getStringProperty( "HelpIcon", "helpIcon", "images/infogreenTr.gif" ) );
      out.write("' border='0'></a>  <!-- ############ -->\r\n");
      out.write("       <br><a href=\"http://www.norsys.com/\" target=\"_new\" class=\"neticaTitle\" style=\"font-size: 12px;cursor: pointer;text-decoration: none;\" >Powered by Netica-Web&trade;</a>\r\n");
      out.write("         ");
      out.write("<BR>\r\n");
      out.write("\t     \r\n");
      out.write("        <table  border=0 cellspacing=0 cellpadding=0 align='center'>\r\n");
      out.write("         <tr><td class=\"neticaTitle\" style=\"text-align:right\">Topic:&nbsp;</td>\r\n");
      out.write("             <td>\r\n");
      out.write("                <SELECT name=\"netSelected\" onchange=\"document.forms[0].submit();\">\r\n");
      out.write("                    ");
      out.print( webQ.getHTMLSelectOptions("Net Names") );
      out.write("\r\n");
      out.write("               </SELECT>\r\n");
      out.write("                <INPUT type=\"hidden\" name=\"reloadNet\" id=\"reloadNetId\" value=\"false\">\r\n");
      out.write("                <INPUT type=\"button\" name=\"reloadNetButton\" value=\"Reload\" class=\"inputButton\"\r\n");
      out.write("                       style='background-color:#AAFFAA;cursor:pointer;display:");
      out.print( webQ.getBooleanProperty("ShowReloadButton",  "showReloadNetButton",  true ) ? "inline": "none" );
      out.write("' \r\n");
      out.write("                       onclick=\"doReloadNet();\">\r\n");
      out.write("             </td>\r\n");
      out.write("         </tr>\r\n");
      out.write("\r\n");
      out.write("         ");
 String domainOptions = webQ.getHTMLSelectOptions("Domain Names"); 
      out.write("\r\n");
      out.write("         <tr ");
      out.print( domainOptions.length() > 0 ? "": "style='display:none'" );
      out.write(">\r\n");
      out.write("           <td class=\"neticaTitle\" style=\"text-align:right\">Domain:&nbsp;</td>\r\n");
      out.write("           <td>\r\n");
      out.write("\r\n");
      out.write("               <SELECT name=\"domainSelected\" onchange=\"document.forms[0].submit();\" >\r\n");
      out.write("                  <OPTION value=\"");
      out.print( webQ.DOMAIN_ALL );
      out.write("\">All\r\n");
      out.write("                  ");
      out.print( domainOptions );
      out.write("\r\n");
      out.write("               </SELECT>\r\n");
      out.write("           </td>\r\n");
      out.write("         </tr>\r\n");
      out.write("        </table>\r\n");
      out.write("    </td>\r\n");
      out.write("\r\n");
      out.write("    <td align='right'>\r\n");
      out.write("    <table  border=0 cellspacing=0 cellpadding=2>\r\n");
      out.write("    <tr>\r\n");
      out.write("   ");
      out.write("\r\n");
      out.write("    <td>\r\n");
      out.write("<INPUT type=\"hidden\" name=\"changeFindings\" id=\"changeFindingsId\" value=\"\">\r\n");
      out.write("<INPUT type=button name=resetFindingsButton value=\" Restart \"  class=\"inputButton\" style=\"width:100;background-color:#AACCFF;\"  onclick=\"doChangeFindings('ResetFindings');\"><BR>\r\n");
      out.write("\r\n");
      out.write(" <INPUT type=\"hidden\" name=\"manageCase\" id=\"manageCaseId\" value=\"\">\r\n");
      out.write(" <INPUT type=button name=manageCaseButton value=\"Save Case\"  class=\"inputButton\" style=\"width:100;background-color:#FFDDBB;\"  onclick=\"doManageCase('Save');\"><BR>\r\n");
      out.write(" \r\n");
      out.write(" <INPUT type=button name=manageCaseButton value=\"Restore Case\"  class=\"inputButton\" style=\"width:100;background-color:#FFEECC;\"  onclick=\"doManageCase('Restore');\"><BR>\r\n");
      out.write(" \r\n");
      out.write("\r\n");
      out.write("<!-- INPUT type=button name=clearFindingsButton value=\"Clear Findings\"  class=\"inputButton\" style=\"background-color:#AACCFF\"  onclick=\"doChangeFindings('ClearFindings');\"-->\r\n");
      out.write("\r\n");
      out.write("   ");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<div style=';display:");
      out.print( webQ.getBooleanProperty("ManualSubmitMode", "showSubmitButtonAndRadioButtons",  false )  ? "inline": "none" );
      out.write("'>\r\n");
      out.write(" <INPUT id=submitButtonId    type=button name=submitButton  ");
      out.print( webQ.getAutoSubmit()? "DISABLED":"" );
      out.write("\r\n");
      out.write("                 Value=\"Submit\" class=\"inputButton\" style=\"width:100;background-color:#AAFFAA\" onclick=\"document.forms[0].submit();\">&nbsp;&nbsp;&nbsp;&nbsp; Submit: \r\n");
      out.write("          <INPUT  type=radio  name=autosubmit  value=\"false\"  onclick=\"disableSubmitButton(false);\"\r\n");
      out.write("\t         ");
      out.print( ! webQ.getAutoSubmit() ? "CHECKED":"" );
      out.write("> Manually\r\n");
      out.write("          <INPUT id=autosubmitRadioTrueId \r\n");
      out.write("\t          type=radio  name=autosubmit  value=\"true\"  onclick=\"disableSubmitButton(true);\"\r\n");
      out.write("\t         ");
      out.print(   webQ.getAutoSubmit() ? "CHECKED":"" );
      out.write("> Automatically</center>\r\n");
      out.write("</div>\r\n");
      out.write("    </td>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("   ");
      out.write("\r\n");
      out.write("    <td valign=\"top\" class=\"neticaTitle\" style=\"text-align:left;line-height:24px\">\r\n");
      out.write("\t");
      out.print( webQ.sysMultDevMode       ? "Site:&nbsp;" + webQ.devToken : "" );
      out.write("&nbsp;<br>\r\n");
      out.write("\t");
      out.print( userExists                ? "User:&nbsp;<span id='userIdId' class='neticaTitle'>"+userId+"</span>" : "" );
      out.write("&nbsp;<br>\r\n");
      out.write("\t");
      out.print( webQ.lastCaseName != null ? "Case:&nbsp;<span id='caseId'   class='neticaTitle'>"+webQ.lastCaseName+"</span>" : "" );
      out.write("&nbsp;<br>\r\n");
      out.write("    </td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  </table>\r\n");
      out.write("  </td>\r\n");
      out.write("\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.print( webQ.getHTMLForReportButtonsRow() );
      out.write("\r\n");
      out.write("\r\n");
 
   String netBlurb = webQ.getNetUserField("NetBlurb", "WebQ_Blurb"); 
   String netTitle = webQ.getNetUserField("NetTitle", "WebQ_Title");
   boolean showBlurbSection = (netBlurb != null && netBlurb.length() > 0) ||
			      (netTitle != null && netTitle.length() > 0)   ;

      out.write("\r\n");
      out.write("\r\n");
      out.write("<div class=\"tableBlurb\" style='display:");
      out.print( showBlurbSection  ? "inline-box":"none" );
      out.write("' >\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table width=\"100%\" border=0 cellspacing=0 cellpadding=0>\r\n");
      out.write("  <tr><td class=\"titleText\">");
      out.print( netTitle );
      out.write("</td></tr>\r\n");
      out.write("  <tr><td class=\"blurbText\">");
      out.print( netBlurb );
      out.write("</td></tr>\r\n");
      out.write("</table>\r\n");
      out.write("</div>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table class=\"tableQ1_Questions\" cellspacing=0 cellpadding=4>\r\n");
      out.write("  <tr><td class=\"questionText\">Questions</td></tr> \r\n");
      out.write("  <tbody>\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Questions") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table class=\"tableQ2_Results\" cellspacing=0 cellpadding=4>\r\n");
      out.write("  <tr>\r\n");
      out.write("   <td class=\"questionText\" style='width:40%'>Results</td>\r\n");
      out.write("   ");
 String bbarLegend =  webQ.getHTMLBBarLegend(); 
      out.write("\r\n");
      out.write("   <td class='");
      out.print( bbarLegend==null || bbarLegend.length()==0 ? "questionText":"bbarLegend" );
      out.write('\'');
      out.write('>');
      out.print( bbarLegend );
      out.write("</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  <tbody>\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Results") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table  class=\"tableQ3_Answered\" cellspacing=0 cellpadding=4\r\n");
      out.write("   style=';display:");
      out.print( webQ.getBooleanProperty( "ShowAnsweredSection", "showAnsweredQuestions",  true ) ? "inline-box": "none" );
      out.write("'>\r\n");
      out.write("  <tr><td colspan=\"50\" class=\"questionText\">Answered</td></tr>\r\n");
      out.write("  <tbody>\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Answered") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table class=\"tableQ4_Skipped\" cellspacing=0 cellpadding=4\r\n");
      out.write("   style=';display:");
      out.print( webQ.showSkippedQuestionsSection() ? "inline-box": "none" );
      out.write("'>\r\n");
      out.write("  <tr><td colspan=\"50\" class=\"questionText\">Skipped</td></tr>\r\n");
      out.write("  <tbody>\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Skipped") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table class=\"tableQ5_Irrelevant\" cellspacing=0 cellpadding=4 \r\n");
      out.write("   style=';display:");
      out.print( webQ.showIrrelevantQuestionsSection() ? "inline-box": "none" );
      out.write("'>\r\n");
      out.write("  <tr><td colspan=\"50\" class=\"questionText\">Irrelevant<input type=\"button\" name=\"irrelevantButton\" value=\"+\" onclick=\"javascript:handleIrrelevant(this);\" class=\"irrelevantButton\"></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  <tbody id=\"irrelevantBodyId\">\r\n");
      out.write("    ");
      out.print( webQ.getHTMLRows("Irrelevant") );
      out.write("\r\n");
      out.write("  </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table class=\"tableQ6_Log\" cellspacing=0 cellpadding=4 \r\n");
      out.write("   style=';display:");
      out.print( webQ.showLogSection() ? "inline-box": "none" );
      out.write("'>\r\n");
      out.write("  <tr><td class=\"questionText\">Log</td></tr>\r\n");
      out.write("    <tr><td class=\"logText\">\r\n");
      out.write("      ");
      out.print( webQ.getLog() );
      out.write("\r\n");
      out.write("    </td></tr>\r\n");
      out.write("</table>\r\n");
      out.write("\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("\r\n");
      out.write("<SCRIPT LANGUAGE=\"JavaScript\">\r\n");
      out.write("function applyFindings(){\r\n");
      out.print( webQ.getFindingsAsJavascript() );
      out.write("\r\n");
      out.write("}\r\n");
      out.write("</SCRIPT>\r\n");
      out.write("\r\n");
      out.write("</html>\r\n");
      out.write("\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
