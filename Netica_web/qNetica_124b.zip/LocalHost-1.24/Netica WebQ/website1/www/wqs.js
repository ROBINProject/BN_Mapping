
 var isIE     = navigator.appName.indexOf("Microsoft Internet Explorer") >=0;
 var isSafari = navigator.vendor != null && navigator.vendor.indexOf("Apple Computer") >=0;
 var isOpera  = navigator.appName != null && navigator.appName.indexOf("Opera") >=0;
 var wqs_slider_values = "0.5,0.0,1.0";
 var wqs_SliderArray = new Array();
//if (!isIE){document.captureEvents(Event.MOUSEMOVE)}

 document.onmouseup   = wqs_onMouseUp;
 document.onmousedown = wqs_onMouseDn;
 window.onresize =      wqs_onResize;
 //document.onscroll    = wqs_onScroll;
// SEE: http://www.webreference.com/programming/javascript/mk/column2/
// http://luke.breuer.com/tutorial/javascript-drag-and-drop-tutorial.aspx


function mouseMove2(ev){    
  ev           = ev || window.event;   
  var mousePos = mouseCoords(ev);   
}   
  
function mouseCoords(ev){   
    if(ev.pageX || ev.pageY){   
         return {x:ev.pageX, y:ev.pageY};   
     }   
     return {   
         x:ev.clientX + document.body.scrollLeft - document.body.clientLeft,   
         y:ev.clientY + document.body.scrollTop  - document.body.clientTop   
     };   
 }   
function mouseX(ev){  
  return ev.pageX ? ev.pageX : 
                    ev.clientX + document.body.scrollLeft - document.body.clientLeft;
}

function getInnerText( elem ){
   return (isIE) ? elem.innerText : elem.textContent;
}

//document.attachEvent("onmousemove", wqs_onMouseMove);
//document.attachEvent("onmouseup", wqs_onMouseUp);

function wqs_reEnableAllWQSText(){
   var sliders = document.getElementsByName( "wqs_slider" );
   wqs_SliderArray = sliders;
    
   for (var i=0; i< sliders.length; i++ ){
     var s = sliders[i];
     if (s.text != null && s.text.disabled ) {
        alert( "enabling : " + s.id );
        s.text.disabled = false;
     }
   }
}

function wqs_init() {
    var sliders = document.getElementsByName( "wqs_slider" );
    wqs_SliderArray = sliders;
    
   for (var i=0; i< sliders.length; i++ ){
     var s = sliders[i];
     var id = s.id;
     var pos = id.indexOf("_slider");
     var parmName = id.substring( 0, pos);

     var qIndex = id.substring( pos+7);
     var handle = document.getElementById( parmName + "_handle"+qIndex );
     var text   = document.getElementById( parmName + "_text"  +qIndex );
     if (handle == null) alert( "wqs_handle" +qIndex +" is NULL!" );
     //alert( s_top );
     //--------------- SLIDER EVENT HANDLERS
     ////s.onmousedown = generic_wqss_onmousedn;
     ///s.onmove = generic_wqss_onmove;
     if (isIE) { 
         s.onmousedown =    new Function( "return wqss_onmousedn();" );
     }
     else {
         s.onclick = new Function( "return wqss_onmousedn();" );
     }
   //s.onmouseup   = generic_wqss_onmouseup;
   
     s["parmName"] = parmName;
     s["qIndex"]   = qIndex;
     s["handle"]   = handle;
     s["text" ]    = text;
     s["dirtyBit"] = document.getElementById( parmName + "_dirtyBit" );
     s["min"]      = 0.0;
     s["max"]      = 1.0;
     s["range"]    = 1.0;

     //-- adjust min/max for real valued slider
     var minRangeElem = document.getElementById( parmName + '_min' );
     if (minRangeElem != null) {
	s.min = new Number( getInnerText(minRangeElem ));
    	var maxRangeElem = document.getElementById( parmName + '_max' );
     	if (maxRangeElem != null) s.max = new Number( getInnerText(maxRangeElem ));
	s.range = s.max - s.min;
     }
     
     //--------------- HANDLE EVENT HANDLERS
     handle["slider"] = s;
     handle["dragMode"] = false;

   //handle.onmousemove = generic_wqsh_onmousemv;
   //handle.onmousedown = generic_wqsh_onmousedn;
   //handle.ondrag      = generic_wqsh_onmousedg;
     wqs_positionHandle(s);
     //--------------- TEXT EVENT HANDLERS
     //if (isIE) text.onchange = generic_wqst_onchange; else
     //text.addEventListener("change", generic_wqst_onchange, true);
     //text.onsubmit = null;
     text["slider"] = s;
     text["dirtyBit"] = document.getElementById( parmName + "_dirtyBit" );
   }
    wqs_onScroll(); //fix FF scrolling bug
 }
//-- SLIDER EVENT HANDLERS
//var generic_wqss_onmousedn   = new Function( "return wqss_onmousedn();" );
//var generic_wqss_onmouseup   = new Function( "return wqss_onmouseup();" );
//var generic_wqss_onmove      = new Function( "return wqss_onmove();" );
//-- HANDLE EVENT HANDLERS
//var generic_wqsh_onmousemv   = new Function( "return wqsh_onmousemv();" );
//var generic_wqsh_onmousedg   = new Function( "return wqsh_onmousedg();" );
//var generic_wqsh_onmousedn   = new Function( "return wqsh_onmousedn();" );
//--   TEXT EVENT HANDLERS
var generic_wqst_onchange   = new Function( "return wqst_onchange();" );



var activeDraggingHandle = null;
var debugTxt = "";
//****************************** GLOBAL DOCUMENT EVENT HANDLERS
function wqs_onMouseMove(evt){
  if (activeDraggingHandle ==null) return; //nothing is being dragged;
   
  if ( !isIE && (evt == null)) return;
  if (isIE) evt = window.event;
  var elem  = isIE ?  evt.srcElement : evt.target ;
  if (elem.disabled) return;
  var id = elem.id;
  if ( (id!=null) && 
       (id.indexOf("wq_") == 0) ) {
    //var newX  = isIE ? evt.x : evt.pageX; 
    //var mousePos = mouseCoords(evt);  
    //newX = mousePos.x;
    newX = mouseX(evt);
    wqss_mvcUpdateFromHandle( activeDraggingHandle.slider, activeDraggingHandle, newX, evt );
    return false;
  }
     
  //moved outside a slider, so stop dragging
  //activeDraggingHandle = null; 
  return false;
}

var handleWidth  = 8;//actually half the width  //isIE ? 5 : 8;
var handleWidth2 = isIE ? 5 : 8;
function wqss_mvcUpdateFromHandle( s, h, newX, evt ){

  if ( newX  < s.doc_left ) {
     ////alert( newX + " < " + s.doc_left );
      var elem  = isIE ?  evt.srcElement : evt.target ;
      ////alert( elem.tagName + " " + elem.id );
     newX = s.doc_left ; 
  }
  else {
    if ( newX > s.doc_right) newX = s.doc_right-1 ;
  }

  h.style.left  = (newX - handleWidth )+"px" //move handle
  var newValue =         (newX - s.doc_left)/s.offsetWidth;
  s.text.value = roundTo2DecPlaces(newValue * s.range + s.min);
  s.dirtyBit.value = 1;
}

function roundTo2DecPlaces( n ) {
  return Math.round( n * 100.0 ) /100.0;
}

function wqs_onMouseUp(evt){
  if (activeDraggingHandle ==null) return; //nothing is being dragged;
  var s = activeDraggingHandle.slider;
  
  handleSetNodeStateFindingFromSlider( s );

  activeDraggingHandle =  null;
  document.onmousemove =  null;
  return false;
}
function wqs_onMouseDn(evt){
  if (activeDraggingHandle !=null) return; //impossible
  if ( !isIE && (evt == null)) return;
  if (isIE) evt = window.event;
  var elem  = isIE ?  evt.srcElement : evt.target ;
  if (elem.disabled) return;
  var id = elem.id;
  if ( (id!=null) && 
       (id.indexOf("wq_") == 0) ) {

     if ( id.indexOf("_slider" ) > 0 ) { // clicked on a slider
        activeDraggingHandle  = elem.handle;
        wqss_onmousedn(evt);
     }
     else 
     if ( id.indexOf("_handle" ) > 0 ) { // clicked on a handle
        activeDraggingHandle  = elem;
     }
     else {
        return true; //some other element, so ignore
     }
     document.onmousemove = wqs_onMouseMove;
     return false;
  }
  return true;
}
/*
function wqs_onMove(evt){
  if (activeDraggingHandle !=null) return; //impossible
  if ( !isIE && (evt == null)) return;
  if (isIE) evt = window.event;
  var elem  = isIE ?  evt.srcElement : evt.target ;
alert(elem.tagName);
  return false;
}
*/
function wqs_onResize(evt){
  //alert( "Resizing!");
  
    
   for (var i=0; i< wqs_SliderArray.length; i++ ){
     var s = wqs_SliderArray[i];
     wqs_positionHandle(s);
   }
}
function wqs_onScroll(evt){
if (isIE) return;  // only needed for FF 
   var sliders = document.getElementsByName( "wqs_slider" );
   var uaDiv = document.getElementById( "divQ1" );
   if (uaDiv== null) return;//hack, for now; cannot support other divs
   var uaDivTop = getTopPos( uaDiv );
   var uaDivBot = uaDivTop + uaDiv.clientHeight;
    
   for (var i=0; i< sliders.length; i++ ){
     var s = sliders[i];
     var handle = s.handle;
     if ( handle == null ) alert( "handle is NULL!" );
     var s_top  = getTopPosButBreakAtDIVs(s);
     //var s_bot  = s_top  +  s.clientHeight;
 
     var newTop = s_top -3 - uaDiv.scrollTop;
     var newBot = newTop   + handle.clientHeight;

     //-- and clip anything that exceeds our parent's area
     //rect (top, right, bottom, left)
     //var clipTop = 
     if (  newTop < uaDivTop ) {
        handle.style.clip = "rect("+ (uaDivTop - newTop)  +"px, 100px, 50px, 0px)";
     } 
     else
     if ( newBot > uaDivBot ) {
        handle.style.clip = "rect(0px, 100px, "+ ( uaDivBot - newTop)  +"px, 0px)";

     }
      else handle.style.clip = null;

     handle.style.top  = newTop + "px";
   }
}
// **************************************** 

//-- Handle Handlers
function wqsh_onmousedn(evt){
  if ( !isIE && (evt == null)) return;
  if (isIE) evt = window.event;
  var h  = isIE ?  evt.srcElement : evt.target ;
if ( activeDraggingHandle != null) alert( "ERROR activeDraggingHandle is not NULL!!");
  activeDraggingHandle  = h;
  return false;
}
//-- Slider Handlers
function wqss_onmouseup(evt){
  return;
  if ( !isIE && (evt == null)) return;
  if (isIE) evt = window.event;
  var s  = isIE ?  evt.srcElement : evt.target ;
  wqss_mvcUpdateFromHandle( s, s.handle, evt.x + s.s_left, evt );
}
function wqss_onmousedn(evt){
  if ( !isIE && (evt == null)) return;
  if (isIE) evt = window.event;
  var s  = isIE ?  evt.srcElement : evt.target ;


//Secondly: x and y are NOT properties of a mouse event object. You need to EITHER use the event.screenX and event.screenY (to retrieve relative position within the window) OR event.clientX and event.clientY (to retrieve the co-ordinates relative to the element that has been clicked). 
 // var screenX = isIE?  evt.x + s.s_left : evt.screenX;
   var screenX  = mouseX(evt);

  wqss_mvcUpdateFromHandle( s, s.handle, screenX , evt  );
  return false;
}
function wqs_positionHandle(s){
     var handle = s.handle;
if ( handle == null ) alert( "handle is NULL!" );
     var s_top  = getTopPosButBreakAtDIVs(s);
     var s_left = getLeftPosButBreakAtDIVs(s);
     var value = s.text.value; 
     if ( value == null || value.length == 0 ) {
       //-- position it half-way
       value = (s.min + s.max) /2;
       //handle.style.visibility = "hidden";
       //return;
     }
     handle.style.visibility = "visible";
     var value = new Number(value); 
     var value0_1  = (value - s.min)/ s.range;
     var offset = s.offsetWidth * value0_1;
     //handle.style.left = (s_left + offset-2) + "px";     
     handle.style.left = (s_left + offset - handleWidth2) + "px";     
     handle.style.top  = s_top -3 + "px";
     s["s_left"]  = s_left;
     s["s_right"] = s_left + s.offsetWidth;
     s["doc_left"]  = getLeftPos( s );
     s["doc_right"] = s.doc_left + s.offsetWidth;
}

//-- currently, val should be 0 or 1.
function wqs_setSliderValue(txtElemId,val){
  var text = document.getElementById( txtElemId );
  if (text == null) return;
  var s = text.slider;
  text.value = val < 0.5 ? s.min : s.max;
  wqs_positionHandle(s);
  s.dirtyBit.value = 1;
  submitIfAutoSubmitEnabled();
  return false;
}

function wqst_onchange(evt){
  if ( !isIE && (evt == null)) return;
  if (isIE) evt = window.event;
  var textElem  = isIE ?  evt.srcElement : evt.target ;
  var value = textElem.value;
  var num = new Number(value);
  if ( isNaN(num)) {
    alert( "Sorry but " + value + " is not a number." );
    return false;
  }

  var s = textElem.slider
  if ( s != null ){
    var min = s.min;
    var max = s.max;

    if ( num < min ) {
       alert( "Sorry, but the minimum value for this field is " + min + "\n" + num + " will be changed to " + min);
       num = min;
    }
    if ( num > max ) {
       alert( "Sorry, but the maximum value for this field is " + max + "\n" + num + " will be changed to " + max);
       num = max;
    }
    textElem.value = num;
    wqs_positionHandle(s);
    s.dirtyBit.value = 1;
  }
  else {
     var pos =  textElem.name.indexOf( "_text" );
     if ( pos>0 ){
       var parmName = textElem.name.substring(0,pos);
       var textDirtyBit= document.getElementById( parmName + "_dirtyBit" );
       if ( textDirtyBit != null ) textDirtyBit.value = 1;
    }
  }
  return false;
}


function wqst_onkeypress(evt, submitOnAutoSubmit ){
  if ( !isIE && (evt == null)) return;
  if (isIE) evt = window.event;
  
  if ( evt.keyCode == 13 ){
    wqst_onchange(evt);
    if ( submitOnAutoSubmit ) submitIfAutoSubmitEnabled();
  }
}

/*
function handleKeyDown(evt){
  if ( !isIE && (evt == null)) return;
  if (isIE) evt = window.event;
  var elem  = isIE ?  evt.srcElement : evt.target ;
  var keyCode = isIE ? event.keyCode : isSafari ? evt.keyCode : evt.which;  
  ///alert( keyCode );
  //alert( elem.value);
  var index = new Number(elem.id.substring( 25));
  return handleManualEntry(elem,false,evt);
}
*/
//-- Fns for computing the position of an element relative to the entire page
function getLeftPos( elem ) { 
   var ret = 0; 
   while ( elem != null ) {  
    ret += elem.offsetLeft; 
      elem = elem.offsetParent; 
   } 
   return ret; 
} 
function getTopPos( elem ) { 
   var ret = 0; 
   while ( elem != null ) {  
    ret += elem.offsetTop; 
      elem = elem.offsetParent; 
   } 
   return ret; 
} 
//-- Fns for computing the position of an element relative to the first containing DIV or SPAN
function getLeftPosButBreakAtDIVs( ctrl ) { 
   var ret = 0; 
   while ( ( ctrl != null ) && ( ctrl.tagName != "DIV" ) && ( ctrl.tagName != "SPAN" ) ) {  
    ret += ctrl.offsetLeft; 
      ctrl = ctrl.offsetParent; 
   } 
   return ret; 
} 
function getTopPosButBreakAtDIVs( ctrl ) { 
   var ret = 0; 
   while ( ( ctrl != null ) && ( ctrl.tagName != "DIV" ) && ( ctrl.tagName != "SPAN" ) ) {  
    ret += ctrl.offsetTop; 
      ctrl = ctrl.offsetParent; 
   } 
   return ret; 
} 