var isIE     = navigator.appName.indexOf("Microsoft Internet Explorer") >=0;
var isSafari = navigator.vendor != null && navigator.vendor.indexOf("Apple Computer") >=0;
var isOpera  = navigator.appName != null && navigator.appName.indexOf("Opera") >=0;

//-- basic onload handler for all wq panels
function wq_init() {
  var errDialogMsgElem = document.getElementById( "errorDialogMessageId" );
  if ( errDialogMsgElem != null ) {
        var decodedStr = decodeURIComponent( errDialogMsgElem.value );
        decodedStr = replaceAll( decodedStr, "+", " " );
	alert( decodedStr );
  }

  if ( window.applyFindings ) applyFindings();

  //-- Finally apply any pending Javascript
  var pendingJavaScriptElem = document.getElementById( "pendingJavaScriptId" );
  if ( pendingJavaScriptElem != null ) {
     var script = pendingJavaScriptElem.value;
     if ( script.length > 0 ) {
	if ( isIE) window.execScript(script, "JavaScript");
	else window.eval(script);
     }
     pendingJavaScriptElem.value = "";  // clear, to avoid re-execution upon re-load
  }
  else {
    alert( "pendingJavaScriptElem is NULL!");
  }

}

function debugOut( msg ){
  alert( "DebugOut: " + msg );

}

function setRefreshPostBack(){
  var postBackActionElem = document.getElementById( "postBackActionId" );
  postBackActionElem.value = "Refresh";
}

function clearPendingJavaScript(){
  var pendingJavaScriptElem = document.getElementById( "pendingJavaScriptId" );
  if ( pendingJavaScriptElem != null ) {
     pendingJavaScriptElem.value = "";
  }
}


function doSubmit(){
  //wqs_reEnableAllWQSText();

  document.forms[0].submit();
}

//-- BEGIN RAISE OTHER DIALOGS
var loginDoneOnce = false;
var caseDialogType = "unknown";
//function raiseCaseDialog( typ, needLoginFirst ){
function raiseCaseDialog( typ ){
  caseDialogType = typ;
  var userIdElem = document.getElementById( "userIdId" );
  var needLoginFirst = userIdElem == null || userIdElem.value == null || userIdElem.value.length == 0;
  if (!loginDoneOnce && needLoginFirst){
     var response = raiseLoginDialog();
     loginDoneOnce = true;
        //alert( "login response = " + response );
     if ( response == 'cancel') {
        ////alert( "login was Cancelled");
	return; 
     }
  }
  else {
     if (!isIE) raiseCaseDialog_FF(); 
  }

  if (!isIE ) return;  // since thread does not suspend with FF (dialog is not truly modal).

//-- only IE gets executes the following...

  var parms = new Array();
  parms[0] = typ;
  window.showModalDialog( "webQ_CaseDialog_.html", parms, "dialogHeight:400px;dialogWidth:600px;help:No;resizable:Yes;scroll:No;status:No;unadorned:Yes" );

  //-- DEBUGING OPTION:  non modal window
  //window.open("webQ_CaseDialog.jsp","webQCaseDialog", "dialogHeight: 500px; dialogWidth: 500px; help: No; resizable: Yes; status: Yes;");



  if( typ == "Restore" || typ == "Save" ) {
    setRefreshPostBack();
    clearPendingJavaScript();
    document.forms[0].submit();
  }

}

function raiseCaseDialog_FF() {
 //menubar=no;toolbar=no,status=no,titlebar=no,
    var dialog = window.open( "webQ_CaseDialog_.html", "webQCaseDialog", "modal=yes,menubar=no,scrollbars=auto,toolbar=no,status=no,titlebar=no,toolbar=no,height=400,width=600"); 
    dialog.focus(); 

}

function refreshWebQ_FF() {

    setRefreshPostBack();
    clearPendingJavaScript();
    document.forms[0].submit();
}


//var loginReturnValue = 'unknown';
//function setLoginReturnValue( val ){
//  loginReturnValue = val;
//  //alert("loginReturnValue was called with val=" + val );
//}

//var caseDialogReturnValue = 'unknown';
//function setCaseDialogReturnValue( val ){
//  caseDialogReturnValue = val;
//  //alert("loginReturnValue was called with val=" + val );
//}

function raiseLoginDialog(){
  if ( isIE  ){
     //return window.showModalDialog( "webQ_login.jsp" , "", "dialogHeight: 260px; dialogWidth: 400px; help: No; resizable: Yes; scroll: No; status: No; unadorned: Yes");
     return window.showModalDialog( "webQ_login_.html" , "", "dialogHeight: 260px; dialogWidth: 400px; toolbar: No; help: No; resizable: Yes; scroll: No; status: No; unadorned: Yes;menubar=no;toolbar=no,status=no,titlebar=no,");
  }
  else { //-- W3C way
     loginReturnValue = 'unknown';
     // var dialog = window.open("webQ_login_.html", "webQLogin", "modal=yes,menubar=no,scrollbars=auto,status=no,titlebar=no,toolbar=no,height=400,width=600"); 
     var dialog = window.open("webQ_login_.html", "", "modal=yes,menubar=no,status=no,titlebar=no,toolbar=no,resizable=yes,height=260,width=400"); 
     dialog.focus(); 
     //return loginReturnValue;  pointless, since thread was not stopped
  }
}

function showReport(reportNum){
  var w = window.open("webQ_Report.jsp?reportNumber="+reportNum,"webQReport", "menubar=no;toolbar=no,status=no,titlebar=no,resizable,scrollbars,height=800px,width=1000px");
  if (w!=null) w.focus();
}

function showNodeReport(reportNum, nodeName){
  window.open("webQ_NodeReport.jsp?reportNumber="+reportNum+"&nodeName="+nodeName,"webQNodeReport", "menubar=no;toolbar=no,status=no,titlebar=no,resizable,scrollbars,height=400px,width=600px");
}

function showWebQHelp(){
  window.open("help/index.htm","WebQHelp", "menubar=no;toolbar=no,status=no,titlebar=no,resizable,scrollbars,height=600px,width=900px");
}



//-- CREATES A VERY BASIC PLAIN WINDOW (with given left, top, width, height, and bgcolor) FOR THE GIVEN Title and HtmlText
function popup(title, text, left, top, w, h, bgcolor ) {
  var mystuff = "<HTML><title>" + title+ "</title><BODY style='font-family:Verdana;font-size:11px;background-color:"+bgcolor+"'>"+text+"</body></html>";
  var mypop = window.open("","","menubar=no;toolbar=no,status=no,titlebar=no,left="+left+",top="+top+",height="+h+",width="+w+",resizable=1");
  if ( mypop == null ) return;
  mypop.document.write(mystuff);
  mypop.document.close();
  mypop.focus();
  if ( h < 150 ) { mypop.resizeTo( w, h); }
  return mypop;
}

//--  END RAISE OTHER DIALOGS

//-- TOOLTIP
//-- Tooltip scheme
var generic_tthide = new Function( "tthide();" );
var ttObj;

function toolTip( obj,  txt ){
  if ( !isIE ) return; // only supported in IE for now
  if (obj == null ) return; //useful mechanism to disable ttips, just pass 'null' instead of 'this'
  var tt = document.getElementById( 'tt' );
  if ( tt == null ) return false;
  if ( obj == ttObj ) return false;
  ttObj = obj;
  tt.innerText = replaceAll(txt,"<BR>","\n");
  //var srcElem = event.srcElement;

  tt.style.left = event.clientX; // event.clientX + 20;
  tt.style.top  = event.clientY +20 ; // event.clientY;  
  tt.style.display = "inline";
  if (tt.clientWidth < 100 && tt.clientHeight > 30 ){  //if doesn't fit to the right, shift to the far left and 20px below the event.
     tt.style.left = 5;
     tt.style.top  = event.clientY + 20;
  }
  obj.onmouseleave = generic_tthide;
}

function tthide(){
  var tt = document.getElementById( 'tt' );
  tt.style.display = "none";
  ttObj = null;
}
//-- END TOOLTIP



function handleSetNodeStateFindingFromRadio(obj) {
  var autosubmitRadioTrueElem = document.getElementById( "autosubmitRadioTrueId" );
  var parmName = obj.name;
  if ( autosubmitRadioTrueElem != null && autosubmitRadioTrueElem.checked ) {
     //--disable any associated sliders
     var sliders = document.getElementsByName( "wqs_slider");
     if (sliders != null && sliders.length > 0 ){
        for (var i=0; i< sliders.length; i++ ){
           var s = sliders[i];
	   if (s.parmName == parmName ) {
              var s = sliders[i];
    	      s.text.disabled = true; //so that the text is not posted
//alert( " disabled " + s.text.name );
           }
        }
     }
     doSubmit();
  }
	
  //-- we only get here if autosubmit is turned off
  if (obj.checked) {
     //-- set my slider to 1 and all competitors to 0
     var sliders = document.getElementsByName( "wqs_slider");
     if (sliders != null && sliders.length > 0 ){
        for (var i=0; i< sliders.length; i++ ){
           var s = sliders[i];
	   if (s.parmName == parmName ) {
	      var ending  = "_slider"+ obj.value;
	      s.text.value = stringEndsWith( s.id, ending ) ? "1.0": "0.0";
    	      wqs_positionHandle(s);
           }
        }
     }
  }
}


function submitIfAutoSubmitEnabled(){
  var autosubmitRadioTrueElem = document.getElementById( "autosubmitRadioTrueId" );
  if ( autosubmitRadioTrueElem == null || autosubmitRadioTrueElem.checked ) {
    doSubmit();
  }
}


function handleSetNodeStateFindingFromSlider(obj) {
  var parmName = obj.parmName;
  var radios = document.getElementsByName( parmName );
  if (radios != null && radios.length > 0 ){
     for (var i=0; i< radios.length; i++ ){
        var r = radios[i];
	if ( r.name ==  parmName ){
    	    r.disabled = true; //so that the radio is not posted
 	    //alert( " disabled radio " +  parmName );
        }
     }
  }
  submitIfAutoSubmitEnabled();
}

function stringEndsWith( str, pat ) {
  var pos = str.lastIndexOf( pat );
  if (pos < 0) return false;
  return pos == (str.length - pat.length);
}

function disableSubmitButton(val) {
  var submitButtonElem = document.getElementById( "submitButtonId" );
  if ( submitButtonElem != null ) {
  	submitButtonElem.disabled = val;
  }
}

function handleIrrelevant(obj) {
  var ibi = document.getElementById( "irrelevantBodyId" );
  if (ibi != null) {
     if ( obj.value == "+" ){
        ibi.style.display = "none";
	obj.value = "-";
     }
     else{
        ibi.style.display = "inline";
	obj.value = "+";
     }
  }

}

function doReloadNet(){
   document.getElementById( "reloadNetId" ).value = "true";
   doSubmit();
}

//-- typ can currently be "ResetFindings" or "ClearFindings"
function doChangeFindings(typ){
   document.getElementById( "changeFindingsId" ).value = typ;
   doSubmit();
}

function doTakeSnapShot(index){
   document.getElementById( "takeSnapShot"+index+"Id" ).value = "true";
   doSubmit();
}

function doManageCase(typ){
   document.getElementById( "manageCaseId" ).value = typ;
   doSubmit();
}


// This function replaces all instances of A in str with B.
function replaceAll(str,A,B) {
  var pos = 0;  
  var res = ""; 
  while (str.indexOf(A,pos) != -1) {
    res += str.substring(pos,str.indexOf(A,pos));
    res += B;
    pos = (str.indexOf(A,pos) + A.length);     
  }
  res += str.substring(pos,str.length);        
  return res;
}

//-- JAVASCRIPT OBJECT DEFINITION:  WQ_Finding
function WQ_Finding( type, name, value){
this.type = type;
this.name = name;
this.value = value;
}

function applyFinding( type, name, value, notValues ){
//alert( name );

  if (type == "STRAD"){
    var elemArray = document.getElementsByName( name );
    for (var e=0; e<elemArray.length; e++){
      var elem = elemArray[e];

      //-- set +
      if (elem.value == value ) {
	elem.checked = true;
        break;
      }

      //-- set -
      if ( notValues != null ) {
        var notTarget = "|"+elem.value+"|";
        if ( notValues.indexOf( notTarget ) >= 0 ) {
          elem.disabled = true;
	  fakeDisabled( elem.nextSibling );
        } 
      }
    }
  }

  else
  if (type == "ST_DD"){
    var elem = document.getElementsByName( name );

    //-- set +
    if ( value != null ){
    	elem[0].value = value;
    }

    //-- set -
    if ( notValues != null ) {
      var option = elem[0].firstChild;
      while (option != null) {
        var notTarget = "|"+option.value+"|";
        if ( notValues.indexOf( notTarget ) >= 0 ) {
          //fakeDisabled(option);
          option.disabled = true;
        }
        option = option.nextSibling;
      } 
    }
  }

  else
  if ( type == "LK_MS" || "LK_SS" || type == "RESLD" || type == "RETBO" ){
    //-- set +
    if ( value != null ){
      value = ""+value;//ensure it is a String!
      if ( type == "RESLD" && value.indexOf( "ExpectedValue=" ) == 0 ){
	//set the position of the slider, but do not set any finding value
	var expectedVal = value.substring( "ExpectedValue=".length );
	
        var textElem = document.getElementById( name + "_text0"  );
        if ( textElem != null ) {
           textElem.value = expectedVal;
	   //alert( "EV=" +  textElem.value );
 	   var slider = textElem.slider;
           if ( slider != null ) wqs_positionHandle( slider );
           
           textElem.value = ""; // reset, so 
        }

	//alert( "found EV=" + evTxt );
	return;
      }
      var  targetVals = value.split(",");
      for (var t=0; t<targetVals.length; t++){
        var textElem = document.getElementById( name + "_text" + t );
        if ( textElem != null ) {
           textElem.value = targetVals[t];
 	   var slider = textElem.slider;
           if ( slider != null ) wqs_positionHandle( slider );
        }
      }
      if ( value == "0" ) {
      	var elem = document.getElementById( 'stateNameForLeftSingleSlider_' + name );
        if ( elem != null ) elem.className = "stateNameForLeftSingleSliderSelected";
      }
      else if ( value == "1" ) {
      	var elem = document.getElementById( 'stateNameForRightSingleSlider_' + name );
        if ( elem != null ) elem.className = "stateNameForRightSingleSliderSelected";
      }
    }
    //-- set -  
    if ( (type == "LK_MS" || type == "LK_SS" ) && 
	 (notValues != null )) {
      var elemArray = document.getElementsByName( name ); //get radios
      for (var e=0; e<elemArray.length; e++){
        var elem = elemArray[e];
        var notTarget = "|"+elem.value+"|";
//alert(name + "  " + notTarget);
        if ( notValues.indexOf( notTarget ) >= 0 ) {
//alert( "disabling :" + notTarget );
          elem.disabled = true;
	  fakeDisabled( elem.nextSibling );
          var eText = document.getElementById( name + "_text" + e );
	  if ( eText != null ){
             //DO NOT SET THE LKLIHOOD TO ZERO: eText.value = "0.0";
             //var slider = eText.slider;
             //if ( slider != null ) {
             //	 wqs_positionHandle( slider );
 	     //     slider.disabled        = true;
	//alert( "slider is disabled" );
 	     //     slider.handle.disabled = true;
             // }
	     fakeDisabled_BG( eText );
          }
        } 
      } //end for

      elemArray = document.getElementsByName(  );
    }
  }

  else {
    alert( "Unsupported findings type = " + type );
  }

}


//-- CONSTANTS
var GRAY_DISABLED_FG_COLOR = "#777777";
var GRAY_DISABLED_BG_COLOR = "#DDDDDD";

function fakeDisabled( elem ) {
  if (elem != null) {
	elem.style.color           = GRAY_DISABLED_FG_COLOR;
   }
}
function fakeDisabled_BG( elem ) {
  if (elem != null) {
	elem.style.backgroundColor = GRAY_DISABLED_BG_COLOR;
  }
}

function wq_drawLine( elemId, xPos, colr ) {
//'graphicaMeanImgId',200,'red')
  alert( "drawing a Line on elem with ID=" + elemId );
  alert( "at pos=" + xPos );
  alert( "with color=" + colr );
}