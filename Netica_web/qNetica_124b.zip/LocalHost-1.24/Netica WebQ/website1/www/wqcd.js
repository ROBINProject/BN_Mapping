var isIE     = navigator.appName.indexOf("Microsoft Internet Explorer") >=0;
var isSafari = navigator.vendor != null && navigator.vendor.indexOf("Apple Computer") >=0;
var isOpera  = navigator.appName != null && navigator.appName.indexOf("Opera") >=0;
var fileNameElem;
var dialogMode = "";

//-- basic onload handler for all wq panels
function wqcd_init() {
  //top.window.dialogWidth  = "500px";
  //top.window.dialogHeight = "200px";
  fileNameElem = document.getElementById( "caseFileNameId" );
  if (isIE) {
    var parms = top.window.dialogArguments;  //IE only
    dialogMode = parms[0];
  }
  else {
    dialogMode = top.opener.caseDialogType;
  }
  var selectElem = document.getElementById( "dialogModeSelectId" );
  if (selectElem != null && dialogMode != null ) {
      selectElem.value = dialogMode;
      //alert( "selectElem.value = " + selectElem.value );
  }

  var overwriteWarningElem = document.getElementById( "overwriteExistingFileId" );
  if (overwriteWarningElem != null ) {
     if ( confirm( "A file by this name already exists.  Overwrite it?" )){
        overwriteWarningElem.value = "true";
        doSubmit();
     }
  }
}

function wqcd_loginInit() {
 //-- manage loginName cookie
  document.title = "Login";
  var cooky = document.cookie;
  if ( cooky ) { 
    //-- username; webQ_password=; JSESSIONID=372A5CC49D7060D499AF212E44A7744A
    var pos = cooky.indexOf("webQ_userName=");
    if (pos>=0 && (!isIE || cooky.substring(pos,pos+14)== "webQ_userName=")) {
      var userName =  cooky.substring(pos+14);
      var pos2 = userName.indexOf(";");
      if ( pos2 >= 0 ) userName = userName.substring(0,pos2);
      var userNameElem = document.getElementById( "userNameId" );
      userNameElem.value = userName;

      //--reset checkbox too

      var cboxElem = document.getElementById( "saveLoginInfoId" );
      if (cboxElem != null) cboxElem.checked = true;
    }

    //-- password
    var pos = cooky.indexOf("webQ_password=");
    if (pos>=0) {
      var password =  cooky.substring(pos+14);
      var pos2 = password.indexOf(";");
      if ( pos2 >= 0 ) password = password.substring(0,pos2);
      var passwordElem = document.getElementById( "passwordId" );
      passwordElem.value = password;
    }
  }

  //send the client's timezone
  var timezoneElem = document.getElementById( "timezoneId" );
  if (timezoneElem != null) timezoneElem.value = (new Date()).getTimezoneOffset();
}


function debugOut( msg ){
  alert( "DebugOut: " + msg );

}

function closeLogin(result){
  if (isIE ) {
	window.returnValue=result;
        window.close();
  }
  else {
    var openr = top.opener; //window.opener;
    if (openr == null) alert( "OPENER is NULL!" );
    //NOT NEEDED  openr.setLoginReturnValue( result );
    if ( result == 'success' ) openr.raiseCaseDialog_FF();
    top.close();
  }
}


function closeCaseDialog(result){
  if (isIE ) {
	window.returnValue=result;
        window.close();
  }
  else {
    var openr = top.opener; //window.opener;
    if (openr == null) alert( "OPENER is NULL!" );
   //NOT NEEDED  openr.setCaseDialogReturnValue( result );
    if ( result == 'success' ) openr.refreshWebQ_FF();
    top.close();
  }
}


function doSubmit(){
  fileNameElem = document.getElementById( "caseFileNameId" );
  if (fileNameElem != null) {
     //fileNameElem.value = encodeURI( fileNameElem.value );
     fileNameElem.value = replaceAll( fileNameElem.value, "&nbsp;", " " );
     //fileNameElem.value = encodeURIComponent( fileNameElem.value );
  }
  document.forms[0].submit();
}

function submitLogin() {
  var cboxElem = document.getElementById( "saveLoginInfoId" );
  if (cboxElem != null &&  !cboxElem.disabled && cboxElem.checked ) {
    var uName = document.getElementById( "userNameId" ).value;
    var pwd   = document.getElementById( "passwordId" ).value;
    var date = new Date();
    var twoWeeksFromNow = date.getTime() + (56*24*3600*1000);
    date.setTime( twoWeeksFromNow ); 
    document.cookie = "webQ_userName="+uName+"; expires="+ date.toGMTString();
    document.cookie = "webQ_password="+pwd+"; expires="+ date.toGMTString();
  }
  else {
    if (cboxElem != null) {
      //alert("cookies BEFORE: " + document.cookie );
      document.cookie = "webQ_userName=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
      document.cookie = "webQ_password=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
      //alert("cookies AFTER: " + document.cookie );
    }
  }

  doSubmit();
}

function deleteAllCookies() {
  var cookies = document.cookie.split(";");
  for (var i = 0; i < cookies.length; i++) {
    var cookie = cookies[i];
    var eqPos = cookie.indexOf("=");
    var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
    document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
  }
}

function wqcd_rowSelect( evt ){
  if (!isIE && (evt == null)) return;
  var elem = isIE ? window.event.srcElement : evt.target;
  var nameTR = elem.parentNode;
  var nameTD = isIE || isOpera ? nameTR.firstChild :  nameTR.firstChild.nextSibling;
  var fileName = getInnerText(  nameTD );
  //fileName = replaceAll( fileName, "&nbsp;", " " );
  //fileName = replaceAll( fileName, "&nbsp;", " " );
  if ( fileNameElem != null ) fileNameElem.value = fileName;
}

function getInnerText( elem ) {
 var txt = (isIE) ? elem.innerText : elem.textContent;
 txt = decodeURIComponent( txt );
 return txt;
}


function setDialogDimensions(width,height){
    window.dialogWidth  = width  + "px";
    window.dialogHeight = height + "px";
}



function submitOnEnterKey(evt) {
   if (!isIE && (evt == null)) return;
   if (isIE) evt = window.event;
   var elem = isIE ? evt.srcElement : evt.target;
   var keyCode = isIE ? event.keyCode : isSafari ? evt.keyCode : evt.which;
   if ( keyCode == 13 ){
      doSubmit();
   }
}


// This function replaces all instances of A in str with B.
function replaceAll(str,A,B) {
  var pos = 0;  
  var res = ""; 
  while (str.indexOf(A,pos) != -1) {
    res += str.substring(pos,str.indexOf(A,pos));
    res += B;
    pos = (str.indexOf(A,pos) + A.length);     
  }
  res += str.substring(pos,str.length);        
  return res;
}
